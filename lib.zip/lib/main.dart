import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:intl/intl.dart';

void main() {
  runApp(const ShopTrackApp());
}

// ─── Theme ────────────────────────────────────────────────────────────────────

class AppColors {
  static const bg         = Color(0xFF0D0F0E);
  static const surface    = Color(0xFF161A18);
  static const card       = Color(0xFF1C211E);
  static const card2      = Color(0xFF212720);
  static const border     = Color(0xFF2A332D);
  static const green      = Color(0xFF4ADE80);
  static const greenDim   = Color(0x3322C55E);
  static const red        = Color(0xFFF87171);
  static const redDim     = Color(0x33EF4444);
  static const amber      = Color(0xFFFBBF24);
  static const text       = Color(0xFFE8F0EB);
  static const muted      = Color(0xFF7A9080);
}

// ─── Model ────────────────────────────────────────────────────────────────────

class Transaction {
  final int id;
  final String name;
  final double purchase;
  final double paid;
  final double balance;
  final String time;

  Transaction({
    required this.id,
    required this.name,
    required this.purchase,
    required this.paid,
    required this.balance,
    required this.time,
  });

  Map<String, dynamic> toJson() => {
    'id': id, 'name': name, 'purchase': purchase,
    'paid': paid, 'balance': balance, 'time': time,
  };

  factory Transaction.fromJson(Map<String, dynamic> j) => Transaction(
    id: j['id'], name: j['name'], purchase: j['purchase'].toDouble(),
    paid: j['paid'].toDouble(), balance: j['balance'].toDouble(), time: j['time'],
  );
}

// ─── Root App ─────────────────────────────────────────────────────────────────

class ShopTrackApp extends StatelessWidget {
  const ShopTrackApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'ShopTrack',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        scaffoldBackgroundColor: AppColors.bg,
        colorScheme: const ColorScheme.dark(primary: AppColors.green),
        fontFamily: 'monospace',
      ),
      home: const HomePage(),
    );
  }
}

// ─── Home Page ────────────────────────────────────────────────────────────────

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List<Transaction> _transactions = [];
  final _customerCtrl  = TextEditingController();
  final _purchaseCtrl  = TextEditingController();
  final _paidCtrl      = TextEditingController();
  double _balance      = 0;
  bool   _hasInput     = false;

  final _fmt = NumberFormat('#,##,##0.00', 'en_IN');
  String _fmtAmt(double v) => '₹${_fmt.format(v.abs())}';

  @override
  void initState() {
    super.initState();
    _load();
    _purchaseCtrl.addListener(_calc);
    _paidCtrl.addListener(_calc);
  }

  @override
  void dispose() {
    _customerCtrl.dispose();
    _purchaseCtrl.dispose();
    _paidCtrl.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString('shoptrack_tx');
    if (raw != null) {
      final list = jsonDecode(raw) as List;
      setState(() => _transactions = list.map((e) => Transaction.fromJson(e)).toList());
    }
  }

  Future<void> _save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('shoptrack_tx', jsonEncode(_transactions.map((t) => t.toJson()).toList()));
  }

  void _calc() {
    final p = double.tryParse(_purchaseCtrl.text) ?? 0;
    final a = double.tryParse(_paidCtrl.text) ?? 0;
    setState(() {
      _balance  = p - a;
      _hasInput = p > 0 || a > 0;
    });
  }

  void _addTransaction() {
    final purchase = double.tryParse(_purchaseCtrl.text);
    if (purchase == null || purchase <= 0) {
      _showSnack('Please enter a valid purchase amount');
      return;
    }
    final paid    = double.tryParse(_paidCtrl.text) ?? 0;
    final balance = purchase - paid;
    final now     = DateTime.now();
    final tx = Transaction(
      id: now.millisecondsSinceEpoch,
      name: _customerCtrl.text.trim().isEmpty ? 'Customer' : _customerCtrl.text.trim(),
      purchase: purchase,
      paid: paid,
      balance: balance,
      time: DateFormat('hh:mm a').format(now),
    );
    setState(() => _transactions.insert(0, tx));
    _save();
    _customerCtrl.clear();
    _purchaseCtrl.clear();
    _paidCtrl.clear();
    setState(() { _balance = 0; _hasInput = false; });
    _showSnack('Transaction added!');
    HapticFeedback.lightImpact();
  }

  void _deleteTransaction(int id) {
    setState(() => _transactions.removeWhere((t) => t.id == id));
    _save();
    HapticFeedback.mediumImpact();
  }

  void _clearAll() {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: AppColors.card,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        title: const Text('Clear All?', style: TextStyle(color: AppColors.text, fontWeight: FontWeight.bold)),
        content: const Text('This will remove all today\'s transactions.', style: TextStyle(color: AppColors.muted)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel', style: TextStyle(color: AppColors.muted))),
          TextButton(
            onPressed: () { Navigator.pop(context); setState(() => _transactions.clear()); _save(); },
            child: const Text('Clear', style: TextStyle(color: AppColors.red, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  void _showSnack(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg, style: const TextStyle(color: AppColors.bg, fontWeight: FontWeight.bold)),
      backgroundColor: AppColors.green,
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(50)),
      duration: const Duration(seconds: 2),
    ));
  }

  double get _sumTotal   => _transactions.fold(0, (s, t) => s + t.purchase);
  double get _sumPaid    => _transactions.fold(0, (s, t) => s + t.paid);
  double get _sumDue     => _transactions.fold(0, (s, t) => s + (t.balance > 0 ? t.balance : 0));

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: CustomScrollView(
                slivers: [
                  SliverToBoxAdapter(child: _buildHeader()),
                  SliverToBoxAdapter(child: _buildSummaryStrip()),
                  SliverToBoxAdapter(child: _buildDivider()),
                  SliverToBoxAdapter(child: _buildInputPanel()),
                  SliverToBoxAdapter(child: _buildListHeader()),
                  _transactions.isEmpty
                    ? SliverToBoxAdapter(child: _buildEmptyState())
                    : SliverList(
                        delegate: SliverChildBuilderDelegate(
                          (ctx, i) => Padding(
                            padding: const EdgeInsets.fromLTRB(12, 0, 12, 8),
                            child: _TxCard(
                              tx: _transactions[i],
                              fmtAmt: _fmtAmt,
                              onDelete: () => _deleteTransaction(_transactions[i].id),
                            ),
                          ),
                          childCount: _transactions.length,
                        ),
                      ),
                  const SliverToBoxAdapter(child: SizedBox(height: 40)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader() {
    final now = DateTime.now();
    final dateStr = DateFormat('d MMM yy').format(now);
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 10, 20, 16),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('DAILY LEDGER', style: TextStyle(fontSize: 10, letterSpacing: 3, fontWeight: FontWeight.bold, color: AppColors.green)),
                const SizedBox(height: 4),
                RichText(text: const TextSpan(
                  style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900, color: AppColors.text),
                  children: [
                    TextSpan(text: 'Shop'),
                    TextSpan(text: 'Track', style: TextStyle(color: AppColors.green)),
                  ],
                )),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
            decoration: BoxDecoration(
              color: AppColors.card,
              border: Border.all(color: AppColors.border),
              borderRadius: BorderRadius.circular(50),
            ),
            child: Text(dateStr, style: const TextStyle(fontSize: 11, color: AppColors.muted)),
          ),
        ],
      ),
    );
  }

  Widget _buildSummaryStrip() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
      child: Row(children: [
        Expanded(child: _SumCard(label: 'TOTAL',  value: _fmtAmt(_sumTotal), color: AppColors.amber)),
        const SizedBox(width: 8),
        Expanded(child: _SumCard(label: 'PAID',   value: _fmtAmt(_sumPaid),  color: AppColors.green)),
        const SizedBox(width: 8),
        Expanded(child: _SumCard(label: 'DUE',    value: _fmtAmt(_sumDue),   color: AppColors.red)),
      ]),
    );
  }

  Widget _buildDivider() => Container(height: 1, color: AppColors.border, margin: const EdgeInsets.fromLTRB(20, 2, 20, 14));

  Widget _buildInputPanel() {
    // Balance color & text
    Color balColor = AppColors.muted;
    String balText = '—';
    String hintText = '';
    Color hintColor = AppColors.muted;
    if (_hasInput) {
      if (_balance > 0) {
        balColor = AppColors.red; balText = _fmtAmt(_balance);
        hintText = 'Customer owes ${_fmtAmt(_balance)}'; hintColor = AppColors.red;
      } else if (_balance < 0) {
        balColor = AppColors.amber; balText = _fmtAmt(_balance.abs());
        hintText = 'Return change ${_fmtAmt(_balance.abs())}'; hintColor = AppColors.green;
      } else {
        balColor = AppColors.green; balText = 'SETTLED';
        hintText = 'Exact payment ✓'; hintColor = AppColors.green;
      }
    }

    return Container(
      margin: const EdgeInsets.fromLTRB(12, 0, 12, 14),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppColors.surface,
        border: Border.all(color: AppColors.border),
        borderRadius: BorderRadius.circular(18),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('NEW TRANSACTION', style: TextStyle(fontSize: 11, letterSpacing: 2, fontWeight: FontWeight.bold, color: AppColors.muted)),
        const SizedBox(height: 16),

        // Customer Name
        _fieldLabel('CUSTOMER NAME'),
        const SizedBox(height: 7),
        _textField(_customerCtrl, 'e.g. Rajan, Table 3…', isNumber: false),
        const SizedBox(height: 14),

        // Purchase Amount
        _fieldLabel('PURCHASE AMOUNT'),
        const SizedBox(height: 7),
        _amountField(_purchaseCtrl, 'Purchase amount'),
        const SizedBox(height: 14),

        // Amount Paid
        _fieldLabel('AMOUNT PAID'),
        const SizedBox(height: 7),
        _amountField(_paidCtrl, 'Amount paid'),
        const SizedBox(height: 14),

        // Balance
        _fieldLabel('BALANCE DUE'),
        const SizedBox(height: 7),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
          decoration: BoxDecoration(
            color: AppColors.card2,
            border: Border.all(color: AppColors.border),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('BALANCE', style: TextStyle(fontSize: 10, letterSpacing: 2, fontWeight: FontWeight.bold, color: AppColors.muted)),
              Text(balText, style: TextStyle(fontSize: 20, fontWeight: FontWeight.w500, color: balColor)),
            ],
          ),
        ),
        if (hintText.isNotEmpty) ...[
          const SizedBox(height: 5),
          Align(
            alignment: Alignment.centerRight,
            child: Text(hintText, style: TextStyle(fontSize: 10, color: hintColor)),
          ),
        ],
        const SizedBox(height: 16),

        // Add Button
        SizedBox(
          width: double.infinity,
          child: ElevatedButton.icon(
            onPressed: _addTransaction,
            icon: const Icon(Icons.add, size: 18, color: Color(0xFF0A0F0C)),
            label: const Text('ADD TRANSACTION',
              style: TextStyle(fontSize: 13, fontWeight: FontWeight.w800, letterSpacing: 2, color: Color(0xFF0A0F0C))),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.green,
              padding: const EdgeInsets.symmetric(vertical: 15),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              elevation: 0,
            ),
          ),
        ),
      ]),
    );
  }

  Widget _fieldLabel(String label) =>
    Text(label, style: const TextStyle(fontSize: 10, letterSpacing: 1.5, fontWeight: FontWeight.bold, color: AppColors.muted));

  Widget _textField(TextEditingController ctrl, String hint, {bool isNumber = true}) {
    return TextField(
      controller: ctrl,
      keyboardType: isNumber ? const TextInputType.numberWithOptions(decimal: true) : TextInputType.text,
      inputFormatters: isNumber ? [FilteringTextInputFormatter.allow(RegExp(r'[0-9.]'))] : [],
      style: const TextStyle(color: AppColors.text, fontSize: 15),
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: const TextStyle(color: AppColors.muted, fontSize: 13),
        filled: true,
        fillColor: AppColors.card2,
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: AppColors.border)),
        enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: AppColors.border)),
        focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: AppColors.green, width: 1.5)),
      ),
    );
  }

  Widget _amountField(TextEditingController ctrl, String hint) {
    return TextField(
      controller: ctrl,
      keyboardType: const TextInputType.numberWithOptions(decimal: true),
      inputFormatters: [FilteringTextInputFormatter.allow(RegExp(r'[0-9.]'))],
      style: const TextStyle(color: AppColors.text, fontSize: 16),
      decoration: InputDecoration(
        hintText: '0.00',
        hintStyle: const TextStyle(color: AppColors.muted, fontSize: 14),
        prefixText: '₹ ',
        prefixStyle: const TextStyle(color: AppColors.muted, fontSize: 14),
        filled: true,
        fillColor: AppColors.card2,
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: AppColors.border)),
        enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: AppColors.border)),
        focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: AppColors.green, width: 1.5)),
      ),
    );
  }

  Widget _buildListHeader() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 0, 16, 10),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          const Text("TODAY'S LOG", style: TextStyle(fontSize: 11, letterSpacing: 2, fontWeight: FontWeight.bold, color: AppColors.muted)),
          Row(children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
              decoration: BoxDecoration(
                color: AppColors.card,
                border: Border.all(color: AppColors.border),
                borderRadius: BorderRadius.circular(50),
              ),
              child: Text(
                '${_transactions.length} ${_transactions.length == 1 ? "entry" : "entries"}',
                style: const TextStyle(fontSize: 11, color: AppColors.green),
              ),
            ),
            const SizedBox(width: 8),
            GestureDetector(
              onTap: _transactions.isEmpty ? null : _clearAll,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                decoration: BoxDecoration(
                  border: Border.all(color: AppColors.border),
                  borderRadius: BorderRadius.circular(50),
                ),
                child: const Text('Clear', style: TextStyle(fontSize: 10, letterSpacing: 1.5, color: AppColors.muted)),
              ),
            ),
          ]),
        ],
      ),
    );
  }

  Widget _buildEmptyState() {
    return const Padding(
      padding: EdgeInsets.symmetric(vertical: 40),
      child: Column(children: [
        Text('🛒', style: TextStyle(fontSize: 40)),
        SizedBox(height: 12),
        Text('No transactions yet', style: TextStyle(fontSize: 13, letterSpacing: 1, color: AppColors.muted)),
      ]),
    );
  }
}

// ─── Summary Card ─────────────────────────────────────────────────────────────

class _SumCard extends StatelessWidget {
  final String label, value;
  final Color color;
  const _SumCard({required this.label, required this.value, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 10),
      decoration: BoxDecoration(
        color: AppColors.card,
        border: Border(
          top: BorderSide(color: color, width: 2),
          left: BorderSide(color: AppColors.border),
          right: BorderSide(color: AppColors.border),
          bottom: BorderSide(color: AppColors.border),
        ),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Column(children: [
        Text(label, style: const TextStyle(fontSize: 8, letterSpacing: 2, fontWeight: FontWeight.bold, color: AppColors.muted)),
        const SizedBox(height: 6),
        Text(value, style: TextStyle(fontSize: 13, fontWeight: FontWeight.w500, color: color)),
      ]),
    );
  }
}

// ─── Transaction Card ─────────────────────────────────────────────────────────

class _TxCard extends StatelessWidget {
  final Transaction tx;
  final String Function(double) fmtAmt;
  final VoidCallback onDelete;
  const _TxCard({required this.tx, required this.fmtAmt, required this.onDelete});

  @override
  Widget build(BuildContext context) {
    Color accentColor;
    String statusLabel;
    String balText;

    if (tx.balance > 0) {
      accentColor = AppColors.red; statusLabel = 'DUE';
      balText = '-${fmtAmt(tx.balance)}';
    } else if (tx.balance < 0) {
      accentColor = AppColors.amber; statusLabel = 'CHANGE';
      balText = '+${fmtAmt(tx.balance.abs())}';
    } else {
      accentColor = AppColors.green; statusLabel = 'SETTLED';
      balText = '✓ PAID';
    }

    return Container(
      decoration: BoxDecoration(
        color: AppColors.card,
        border: Border(
          left: BorderSide(color: accentColor, width: 3),
          top: BorderSide(color: AppColors.border),
          right: BorderSide(color: AppColors.border),
          bottom: BorderSide(color: AppColors.border),
        ),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(14, 12, 10, 12),
        child: Row(
          children: [
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(tx.name, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: AppColors.text)),
                const SizedBox(height: 3),
                Text(tx.time, style: const TextStyle(fontSize: 10, color: AppColors.muted)),
                const SizedBox(height: 4),
                Text(
                  'Purchase: ${fmtAmt(tx.purchase)}  |  Paid: ${fmtAmt(tx.paid)}',
                  style: const TextStyle(fontSize: 10, color: AppColors.muted),
                ),
              ]),
            ),
            Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
              Text(balText, style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500, color: accentColor)),
              const SizedBox(height: 3),
              Text(statusLabel, style: TextStyle(fontSize: 9, letterSpacing: 1.5, fontWeight: FontWeight.bold, color: accentColor)),
            ]),
            const SizedBox(width: 4),
            IconButton(
              onPressed: onDelete,
              icon: const Icon(Icons.delete_outline, size: 18, color: AppColors.muted),
              padding: EdgeInsets.zero,
              constraints: const BoxConstraints(),
            ),
          ],
        ),
      ),
    );
  }
}
